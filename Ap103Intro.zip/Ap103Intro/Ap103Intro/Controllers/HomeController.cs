﻿using Ap103Intro.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ap103Intro.Controllers
{
    public class HomeController:Controller
    {
        public IActionResult Index()
        {

            //ViewData["StudentName"] = "Kamal";
            //ViewData["StudentAge"] = 20;
            ViewBag.StudentName = "Yusif";
            //ViewBag.Age = 21;
            //Student stu1 = new Student { Id = 1, Name = "Kamal" };
            //Student stu2 = new Student { Id = 2, Name = "Yusif" };
            //List<Student> stuList = new List<Student>();
            //stuList.Add(stu1);
            //stuList.Add(stu2);

            //return Content("salam ap103");
            //ViewResult view = new ViewResult();
            //view.ViewName = "Index";
            //return view;
            //return View();
            //return File("~/img/image.png","images/png");
            //ViewBag.StudentList = stuList;
            TempData["GroupNumber"] = 103;
            return RedirectToAction(nameof(About));
        }
        public IActionResult About()
        {
            //return Json(new
            //{
            //  name="Nurlan",
            //  surname="Hemidov",
            //  age="21"
            //});
            return View();
        }
        public IActionResult GetAll()
        {
            return View();
        }

    }
}
